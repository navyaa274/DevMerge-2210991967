import React from 'react';
import AdvancedAnalyticsDashboard from '../../components/Dashboard/AdvancedAnalyticsDashboard';

const AnalyticsDashboard = () => {
  return <AdvancedAnalyticsDashboard />;
};

export default AnalyticsDashboard;
