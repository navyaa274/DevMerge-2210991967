import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  ChartBarIcon,
  CpuChipIcon,
  ExclamationCircleIcon,
  MagnifyingGlassCircleIcon,
  ShieldCheckIcon,
  UserGroupIcon,
} from "@heroicons/react/24/outline";
import facultyService from "../../services/api/facultyService";
import toast from "../../utils/toast";

export default function CognitiveVisualizer() {
  const [telemetry, setTelemetry] = useState([]);
  const [aggregates, setAggregates] = useState({
    totalProcessingHrs: 0,
    criticalStudents: 0,
    conceptsMastered: 0,
    avgErrorsPerLab: 0,
  });
  const [loading, setLoading] = useState(true);
  const [liveData, setLiveData] = useState(false);

  useEffect(() => {
    const fetchTelemetry = async () => {
      try {
        const res = await facultyService.getCognitiveTelemetry();

        // Handle different response formats
        if (Array.isArray(res)) {
          setTelemetry(res);
        } else if (res.data) {
          setTelemetry(Array.isArray(res.data) ? res.data : []);
        }

        // Handle aggregates
        if (res.aggregates) {
          setAggregates(res.aggregates);
        } else if (typeof res.totalProcessingHrs === "number") {
          setAggregates({
            totalProcessingHrs: res.totalProcessingHrs || 0,
            criticalStudents: res.criticalStudents || 0,
            conceptsMastered: res.conceptsMastered || 0,
            avgErrorsPerLab: res.avgErrorsPerLab || 0,
          });
        }

        // Check if this is live data
        setLiveData(res.liveData || res.isLive || false);
      } catch (error) {
        console.error("Failed to load cognitive telemetry:", error);
        toast.error("Failed to establish telemetry uplink.");
        // Initialize with empty data on error
        setTelemetry([]);
        setAggregates({
          totalProcessingHrs: 0,
          criticalStudents: 0,
          conceptsMastered: 0,
          avgErrorsPerLab: 0,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchTelemetry();
    // Setup polling for real-time vibe
    const interval = setInterval(fetchTelemetry, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="px-4 py-8 md:p-8 lg:p-12 max-w-[1700px] mx-auto min-h-screen pt-20 md:pt-24 font-sans bg-slate-50 dark:bg-slate-950"
    >
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-12 lg:mb-20 gap-8">
        <div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-slate-900 dark:text-white tracking-tighter uppercase leading-none italic">
            Cognitive <span className="text-blue-500">Visualizer</span>
          </h1>
          <p className="mt-4 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest text-[10px] md:text-xs">
            Real-Time Telemetry & Algorithmic Friction Points
          </p>
        </div>
        <div className="flex items-center gap-4 bg-slate-900 px-6 py-4 rounded-3xl border border-slate-800 shadow-2xl">
          <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.8)]"></div>
          <span className="text-[10px] text-white font-black uppercase tracking-widest italic">
            Live Uplink Stream: Connected
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-12">
        <div className="bg-slate-900 p-8 rounded-[3rem] border border-blue-500/30 shadow-[0_0_30px_rgba(59,130,246,0.1)] relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl group-hover:bg-blue-500/20 transition-all"></div>
          <CpuChipIcon className="w-10 h-10 text-blue-500 mb-6" />
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">
            Total Processing Time
          </p>
          <p className="text-4xl font-black text-white italic tracking-tighter">
            {aggregates.totalProcessingHrs} hrs
          </p>
        </div>
        <div className="bg-slate-900 p-8 rounded-[3rem] border border-rose-500/30 shadow-[0_0_30px_rgba(225,29,72,0.1)] relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl group-hover:bg-rose-500/20 transition-all"></div>
          <ExclamationCircleIcon className="w-10 h-10 text-rose-500 mb-6" />
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">
            Critical Friction Students
          </p>
          <p className="text-4xl font-black text-white italic tracking-tighter">
            {aggregates.criticalStudents}
          </p>
        </div>
        <div className="bg-slate-900 p-8 rounded-[3rem] border border-emerald-500/30 shadow-[0_0_30px_rgba(16,185,129,0.1)] relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition-all"></div>
          <ShieldCheckIcon className="w-10 h-10 text-emerald-500 mb-6" />
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">
            Concepts Mastered
          </p>
          <p className="text-4xl font-black text-white italic tracking-tighter">
            {aggregates.conceptsMastered}
          </p>
        </div>
        <div className="bg-slate-900 p-8 rounded-[3rem] border border-amber-500/30 shadow-[0_0_30px_rgba(245,158,11,0.1)] relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl group-hover:bg-amber-500/20 transition-all"></div>
          <ChartBarIcon className="w-10 h-10 text-amber-500 mb-6" />
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">
            Average Compile Errors
          </p>
          <p className="text-4xl font-black text-white italic tracking-tighter">
            {aggregates.avgErrorsPerLab} / lab
          </p>
        </div>
      </div>

      <div className="bg-white dark:bg-dark-900 rounded-[3rem] shadow-3xl border border-slate-100 dark:border-dark-800 p-8 md:p-12 overflow-hidden">
        <div className="flex justify-between items-center mb-10">
          <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic flex items-center gap-4">
            <MagnifyingGlassCircleIcon className="w-8 h-8 text-blue-500" />
            Live Friction Map
          </h2>
          <div className="flex gap-4">
            <button className="px-6 py-2 bg-slate-100 dark:bg-dark-950 text-[10px] font-black uppercase tracking-widest rounded-xl text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors">
              Filter Cohort
            </button>
            <button className="px-6 py-2 bg-blue-600/10 text-[10px] font-black uppercase tracking-widest rounded-xl text-blue-600 dark:text-blue-400 border border-blue-500/20 hover:bg-blue-600/20 transition-colors">
              Export Telemetry
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-100 dark:border-dark-800 text-[10px] uppercase font-black tracking-[0.2em] text-slate-400">
                <th className="py-6 px-4">Student Node</th>
                <th className="py-6 px-4">Focus Area</th>
                <th className="py-6 px-4">Status</th>
                <th className="py-6 px-4 text-center">Compile Errors</th>
                <th className="py-6 px-4">Time Spent</th>
                <th className="py-6 px-4">Last Output</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="6" className="py-20 text-center">
                    <div className="inline-flex items-center gap-3 text-blue-500 uppercase font-black text-sm tracking-widest italic animate-pulse">
                      <CpuChipIcon className="w-6 h-6 animate-spin" /> Scanning
                      Active Memory...
                    </div>
                  </td>
                </tr>
              ) : (
                telemetry.map((data, idx) => (
                  <tr
                    key={idx}
                    className="border-b border-slate-50 dark:border-dark-800/50 hover:bg-slate-50 dark:hover:bg-dark-950/50 transition-colors group"
                  >
                    <td className="py-6 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300">
                          <UserGroupIcon className="w-5 h-5" />
                        </div>
                        <span className="font-bold text-sm text-slate-900 dark:text-white">
                          {data.student}
                        </span>
                      </div>
                    </td>
                    <td className="py-6 px-4 font-mono text-xs text-blue-500 dark:text-blue-400 font-bold">
                      {data.topic}
                    </td>
                    <td className="py-6 px-4">
                      <span
                        className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                          data.status === "critical"
                            ? "bg-rose-500/10 text-rose-600 border-rose-500/20 animate-pulse"
                            : data.status === "warning"
                              ? "bg-amber-500/10 text-amber-600 border-amber-500/20"
                              : "bg-emerald-500/10 text-emerald-600 border-emerald-500/20"
                        }`}
                      >
                        {data.status}
                      </span>
                    </td>
                    <td className="py-6 px-4 text-center">
                      <span
                        className={`text-xl font-black italic tracking-tighter ${data.errors > 20 ? "text-rose-500" : "text-slate-900 dark:text-white"}`}
                      >
                        {data.errors}
                      </span>
                    </td>
                    <td className="py-6 px-4 text-slate-500 text-sm font-bold">
                      {data.timeSpent}
                    </td>
                    <td className="py-6 px-4">
                      <div className="bg-slate-100 dark:bg-slate-900 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 text-[10px] font-mono text-rose-500 dark:text-rose-400 truncate max-w-xs">
                        {data.lastError}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
