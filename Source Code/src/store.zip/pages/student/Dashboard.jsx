import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { useAuthStore } from '../../store/authStore';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

import {
  CpuChipIcon,
  RocketLaunchIcon,
  HeartIcon,
  AcademicCapIcon,
  BoltIcon,
  MagnifyingGlassCircleIcon,
  ChartBarIcon,
  SignalIcon,
  ChevronRightIcon,
  CommandLineIcon
} from '@heroicons/react/24/outline';
import studentService from '../../services/api/studentService';
import analyticsService from '../../services/api/analyticsService';
import weaknessService from '../../services/api/weaknessService';
import labService from '../../services/api/labService';
import Leaderboard from '../../components/Gamification/Leaderboard';
import Badges from '../../components/Gamification/Badges';
import Points from '../../components/Gamification/Points';

const STAT_CARDS = [
  { label: 'Academic Standing', key: 'level', icon: <AcademicCapIcon />, color: 'indigo' },
  { label: 'Next Score Forecast', key: 'score', icon: <SignalIcon />, color: 'blue' },
  { label: 'Cognitive Gaps', key: 'gaps', icon: <MagnifyingGlassCircleIcon />, color: 'amber' },
  { label: 'Interv. Matrix', key: 'intervention', icon: <HeartIcon />, color: 'rose' },
];

const PERFORMANCE_METRICS = [
  { label: 'Attendance Sync', key: 'attendanceSync', bgClass: 'from-blue-600 to-blue-400' },
  { label: 'Curriculum Completion', key: 'curriculumCompletion', bgClass: 'from-indigo-600 to-indigo-400' },
  { label: 'Assignment Velocity', key: 'assignmentVelocity', bgClass: 'from-violet-600 to-violet-400' },
];

const QUICK_ACTIONS = [
  { name: 'Dev Port', path: '/student/developer-portfolio', icon: <RocketLaunchIcon />, color: 'violet' },
  { name: 'HUD Test', path: '/student/global-hud', icon: <HeartIcon />, color: 'rose' },
  { name: 'Labs', path: '/student/labs', icon: <AcademicCapIcon />, color: 'blue' },
  { name: 'Predict', path: '/student/predictive', icon: <SignalIcon />, color: 'indigo' },
  { name: 'Tutor', path: '/student/ai-tutor', icon: <CpuChipIcon />, color: 'amber' },
  { name: 'Leader', path: '/student/leaderboard', icon: <ChartBarIcon />, color: 'fuchsia' },
  { name: 'Interview', path: '/student/mock-interview', icon: <HeartIcon />, color: 'rose' },
  { name: 'Problems', path: '/problems', icon: <CommandLineIcon />, color: 'emerald' },
  { name: 'Course', path: '/student/courses', icon: <AcademicCapIcon />, color: 'emerald' },
];

const ACHIEVEMENTS_FALLBACK = [
  { icon: '🏆', title: 'Problem Solver', desc: 'Solved 10 coding problems' },
  { icon: '🔥', title: 'Streak Master', desc: '7-day learning streak' },
  { icon: '🎓', title: 'Knowledge Sharer', desc: 'Helped 5 classmates' }
];

export default function StudentDashboard() {
  const { user } = useAuthStore();
  const [stats, setStats] = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [weakness, setWeakness] = useState(null);
  const [mySubmissions, setMySubmissions] = useState([]);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [overallProgress, setOverallProgress] = useState([]);
  const [suggestedLabs, setSuggestedLabs] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEverything();
  }, [user.id]);

  const fetchEverything = useCallback(async () => {
    try {
      const [profileRes, predictRes, weaknessRes, submissionRes, progressRes, labsRes, achievementRes] = await Promise.allSettled([
        studentService.getProfileOverview(),
        analyticsService.getPerformancePrediction(user.id),
        weaknessService.getDiagnosis(user.id),
        studentService.getSubmissions(),
        studentService.getOverallProgress(user.id),
        labService.getSuggestedLabs(),
        studentService.getAchievements(user.id)
      ]);

      if (profileRes.status === 'fulfilled') {
        setStats(profileRes.value.data);
        setEnrolledCourses(profileRes.value.data.enrolledCourses || []);
      }
      if (predictRes.status === 'fulfilled') setPrediction(predictRes.value);
      if (weaknessRes.status === 'fulfilled') setWeakness(weaknessRes.value.analysis);
      if (submissionRes.status === 'fulfilled') setMySubmissions(submissionRes.value.data || []);
      if (progressRes.status === 'fulfilled') setOverallProgress(progressRes.value.data || []);
      if (labsRes.status === 'fulfilled') setSuggestedLabs(labsRes.value.data || []);
      if (achievementRes.status === 'fulfilled') setAchievements(achievementRes.value.data || []);
    } catch (error) {
      console.error('Error fetching student dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }, [user.id]);

  const statValues = useMemo(() => ({
    level: prediction?.prediction?.level || 'Active',
    score: `${prediction?.prediction?.predictedExamScore || 0}%`,
    gaps: weakness?.weakTopicsCount || 0,
    intervention: weakness?.interventionRequired ? 'Action Required' : 'Stable'
  }), [prediction, weakness]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#020617]">
        <div className="relative">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="w-24 h-24 border-t-2 border-b-2 border-indigo-500 rounded-full"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-4 h-4 bg-indigo-500 rounded-full animate-pulse shadow-[0_0_15px_rgba(99,102,241,0.5)]"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-[1700px] mx-auto min-h-screen font-sans p-6 md:p-12"
    >
      {/* Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-24 gap-12">
        <div className="w-full xl:w-auto">
          <motion.h1 
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="text-7xl sm:text-8xl md:text-9xl font-black text-white tracking-[0.2em] uppercase leading-none italic"
          >
            LEARNING <span className="text-indigo-500">LEDGER</span>
          </motion.h1>
          <p className="text-indigo-400 font-bold uppercase tracking-[0.5em] text-[10px] mt-8 flex items-center gap-3">
            <span className="w-3 h-3 bg-indigo-500 rounded-full animate-pulse shadow-[0_0_15px_rgba(99,102,241,0.8)]"></span>
            NEURAL VECTOR: {stats?.academicYear || 'ACTIVE CYCLE'} • NODE: 0x{(user?.id || user?._id || '0000').toString().slice(-4).toUpperCase()}
          </p>
        </div>
        <motion.div 
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="w-full xl:w-auto bg-slate-950/50 backdrop-blur-3xl px-12 py-8 rounded-[4rem] border border-white/10 shadow-3xl flex items-center gap-8 relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-transparent"></div>
          <div className="w-20 h-20 bg-gradient-to-br from-indigo-600 to-indigo-900 rounded-[2rem] flex items-center justify-center text-white border border-white/20 shadow-2xl relative z-10 shrink-0">
            <CpuChipIcon className="w-10 h-10" />
          </div>
          <div className="relative z-10">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] leading-none mb-2">AUTHENTICATED NATIVE</p>
            <p className="text-3xl font-black text-white leading-none italic truncate tracking-tighter">{user?.name || 'STUDENT NODE'}</p>
          </div>
        </motion.div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
        {STAT_CARDS.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
            whileHover={{ scale: 1.05, rotateY: 5 }}
            className="bg-slate-950/40 backdrop-blur-2xl p-10 rounded-[4rem] shadow-2xl border border-white/10 relative overflow-hidden group"
          >
            <div className={`p-5 bg-${stat.color}-500/10 rounded-3xl w-fit mb-8 text-${stat.color}-400 border border-${stat.color}-500/20`}>
              <div className="w-8 h-8">{stat.icon}</div>
            </div>
            <p className="text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4 leading-none">{stat.label}</p>
            <p className={`text-5xl font-black text-white tracking-tighter leading-none italic ${stat.key === 'intervention' && statValues.intervention === 'Action Required' ? 'text-rose-500 animate-pulse' : ''}`}>
              {statValues[stat.key]}
            </p>
            <div className="absolute top-0 right-0 p-10 opacity-[0.05] group-hover:opacity-20 transition-opacity">
              <div className="w-24 h-24">{stat.icon}</div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-24">
        <div className="lg:col-span-8 flex flex-col gap-12">
          {/* Cognitive Analysis */}
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-indigo-950/30 backdrop-blur-3xl rounded-[4.5rem] p-12 text-white border border-indigo-500/20 shadow-3xl relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-[40rem] h-[40rem] bg-indigo-500/5 rounded-full -mr-40 -mt-40 blur-[100px]"></div>
            <div className="relative z-10 flex flex-col lg:flex-row items-center gap-12">
              <div className="w-28 h-28 bg-white/5 rounded-[2.5rem] flex items-center justify-center text-6xl shadow-inner border border-white/10 group-hover:rotate-12 transition-transform shrink-0">🤖</div>
              <div className="flex-1 text-center lg:text-left">
                <h2 className="text-4xl font-black uppercase tracking-tighter mb-4 italic">COGNITIVE ANALYSIS ENGINE</h2>
                <p className="text-sm font-bold text-slate-400 uppercase tracking-widest leading-relaxed max-w-xl italic">
                  {weakness?.weakTopicsCount > 0
                    ? `DETECTED ${weakness.weakTopicsCount} CRITICAL WEAKNESSES IN ${stats?.program}. INITIALIZE STUDY-PATH OPTIMIZATION TO RESOLVE KNOWLEDGE GAPS.`
                    : 'OPERATIONAL STATUS IS NOMINAL. NO CRITICAL COGNITIVE GAPS DETECTED IN CURRENT VECTOR.'}
                </p>
              </div>
              <Link to="/student/weakness-analysis" className="w-full lg:w-auto bg-indigo-500 text-white px-10 py-6 rounded-[2rem] font-black uppercase text-xs tracking-[0.3em] shadow-2xl hover:bg-indigo-600 transition-all flex items-center justify-center gap-3 italic shrink-0 group-hover:scale-105">
                <MagnifyingGlassCircleIcon className="w-6 h-6" />
                REVIEW GAPS
              </Link>
            </div>
          </motion.div>

          {/* Performance & Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Performance Matrix */}
            <motion.div 
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="bg-slate-950/40 backdrop-blur-2xl rounded-[4rem] p-12 shadow-3xl border border-white/10"
            >
              <h3 className="text-2xl font-black mb-12 text-white uppercase tracking-tighter italic flex items-center justify-between leading-none">
                PERFORMANCE MATRIX
                <ChartBarIcon className="w-8 h-8 text-indigo-500" />
              </h3>
              <div className="space-y-10">
                {PERFORMANCE_METRICS.map((metric, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-[11px] font-black uppercase tracking-[0.3em] mb-4">
                      <span className="text-slate-500">{metric.label}</span>
                      <span className="text-white italic">{stats?.performance?.[metric.key] || 0}%</span>
                    </div>
                    <div className="h-5 w-full bg-slate-900 rounded-full overflow-hidden p-1 border border-white/5">
                      <motion.div 
                        initial={{ width: 0 }} 
                        animate={{ width: `${stats?.performance?.[metric.key] || 0}%` }} 
                        className={`h-full rounded-full bg-gradient-to-r ${metric.bgClass} shadow-[0_0_15px_rgba(99,102,241,0.3)]`} 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Quick Actions */}
            <motion.div 
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="bg-slate-950/40 backdrop-blur-2xl rounded-[4rem] p-12 shadow-3xl border border-white/10"
            >
              <h3 className="text-2xl font-black mb-12 text-white uppercase tracking-tighter italic leading-none">
                NEURAL CONSOLE
              </h3>
              <div className="grid grid-cols-3 gap-8">
                {QUICK_ACTIONS.map((action, i) => (
                  <Link key={i} to={action.path} className="flex flex-col items-center group">
                    <motion.div 
                      whileHover={{ scale: 1.2, rotate: 10 }}
                      className="w-20 h-20 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-3xl shadow-xl group-hover:bg-indigo-500 group-hover:text-white group-hover:border-indigo-400 transition-all duration-300"
                    >
                      {action.icon}
                    </motion.div>
                    <span className="mt-4 text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] text-center italic">{action.name}</span>
                  </Link>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-4 flex flex-col gap-12">
          {/* Prediction Card */}
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-gradient-to-br from-indigo-600 via-indigo-900 to-black rounded-[4.5rem] p-12 text-white shadow-3xl relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full -mr-40 -mt-40 blur-[120px] group-hover:scale-150 transition-transform duration-1000"></div>
            <RocketLaunchIcon className="w-20 h-20 text-white/10 absolute right-12 top-12 rotate-12 group-hover:scale-125 transition-transform" />

            <h3 className="text-2xl font-black uppercase tracking-tighter mb-16 italic relative z-10 leading-none">
              FORECAST UPLINK
            </h3>
            <div className="text-center py-16 relative z-10">
              <motion.p 
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                className="text-9xl font-black tracking-tighter italic mb-4 leading-none"
              >
                {prediction?.prediction?.predictedExamScore || 0}%
              </motion.p>
              <p className="text-[11px] font-black uppercase tracking-[0.5em] text-indigo-300">ESTIMATED ATTAINMENT</p>
            </div>
            <div className="mt-12 bg-black/40 backdrop-blur-xl rounded-[3rem] p-8 border border-white/10 relative z-10">
              <p className="text-[10px] font-black uppercase tracking-[0.3em] mb-6 text-indigo-400 italic flex items-center gap-3">
                <BoltIcon className="w-5 h-5" /> AI SUGGESTION
              </p>
              <p className="text-xs font-bold leading-relaxed italic opacity-90 uppercase tracking-widest">
                {prediction?.recommendations?.[0]?.message || 'MAINTAIN CURRENT VECTOR FOR PEAK OPERATIONAL STABILITY.'}
              </p>
            </div>
          </motion.div>

          {/* Recent Submissions */}
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="bg-slate-950/40 backdrop-blur-2xl rounded-[4rem] p-12 shadow-3xl border border-white/10"
          >
            <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-12 italic flex items-center justify-between leading-none">
              SUBMISSIONS
              <SignalIcon className="w-8 h-8 text-indigo-500" />
            </h3>
            <div className="space-y-6 relative">
              {mySubmissions.length > 0 ? mySubmissions.slice(0, 5).map((sub, idx) => (
                <motion.div 
                  key={idx} 
                  whileHover={{ x: 10 }}
                  className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/5 group hover:border-indigo-500/50 transition-all"
                >
                  <div className="flex items-center gap-6 flex-1 min-w-0">
                    <div className={`w-3 h-3 rounded-full flex-shrink-0 ${sub.status === 'accepted' ? 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)]' : 'bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.5)]'}`}></div>
                    <div className="min-w-0">
                      <p className="text-xs font-black text-white uppercase tracking-tighter truncate italic">{sub.problem?.title || 'CODING TASK'}</p>
                      <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-1">{sub.language}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4 italic">
                    {new Date(sub.submittedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                  </span>
                </motion.div>
              )) : (
                <div className="py-20 bg-white/5 rounded-[3rem] border-2 border-dashed border-white/10 text-center px-10">
                  <p className="text-[11px] font-bold text-slate-500 uppercase italic tracking-widest leading-loose">
                    AWAITING INITIAL TRANSMISSION FROM THIS NODE.
                  </p>
                </div>
              )}
            </div>
            {mySubmissions.length > 0 && (
              <Link to="/student/submissions" className="mt-12 block text-center text-[11px] font-black text-indigo-500 uppercase tracking-[0.4em] hover:translate-x-2 transition-all italic">
                LOGS —→
              </Link>
            )}
          </motion.div>
        </div>
      </div>

      {/* Gamification Hub */}
      <div className="mt-24">
        <h2 className="text-5xl font-black text-white mb-16 uppercase tracking-tighter italic leading-none">
          GAMIFICATION <span className="text-indigo-500">HUB</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          <motion.div whileHover={{ scale: 1.02 }} className="bg-slate-950/40 backdrop-blur-2xl rounded-[4rem] p-12 shadow-3xl border border-white/10"><Badges userId={user.id} /></motion.div>
          <motion.div whileHover={{ scale: 1.02 }} className="bg-slate-950/40 backdrop-blur-2xl rounded-[4rem] p-12 shadow-3xl border border-white/10"><Points userId={user.id} /></motion.div>
          <motion.div whileHover={{ scale: 1.02 }} className="bg-slate-950/40 backdrop-blur-2xl rounded-[4rem] p-12 shadow-3xl border border-white/10"><Leaderboard /></motion.div>
        </div>
      </div>

      {/* Course Matrix */}
      <div className="mt-24">
        <h2 className="text-5xl font-black text-white mb-16 uppercase tracking-tighter italic leading-none">
          COURSE <span className="text-indigo-500">MATRIX</span>
        </h2>
        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-slate-950/40 backdrop-blur-2xl rounded-[5rem] p-16 shadow-3xl border border-white/10"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {enrolledCourses.length > 0 ? enrolledCourses.map((course, idx) => (
              <motion.div 
                key={idx} 
                whileHover={{ y: -15 }}
                className="bg-white/5 p-10 rounded-[3.5rem] border border-white/5 group hover:border-indigo-500/50 transition-all flex flex-col"
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="w-16 h-16 bg-indigo-600 rounded-[1.5rem] flex items-center justify-center text-white font-black text-lg italic shadow-2xl shadow-indigo-600/30 group-hover:rotate-12 transition-transform">
                    {(course.code || 'CS').toUpperCase().slice(0, 3)}
                  </div>
                  <span className="px-5 py-2 bg-emerald-500/10 text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-500/20">
                    ACTIVE NODE
                  </span>
                </div>
                <h3 className="text-2xl font-black text-white mb-4 tracking-tighter italic uppercase leading-tight">{course.title}</h3>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-10 leading-relaxed line-clamp-3 italic">{course.description || 'NO DESCRIPTION AVAILABLE.'}</p>
                <div className="mb-10">
                  <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.3em] mb-4">
                    <span className="text-slate-500">SYNC RANK</span>
                    <span className="text-indigo-400 italic">{course.progress || 0}%</span>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-4 p-1 border border-white/5">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${course.progress || 0}%` }}
                      className="bg-gradient-to-r from-indigo-600 to-indigo-400 h-full rounded-full shadow-[0_0_15px_rgba(99,102,241,0.3)] transition-all duration-1000"
                    ></motion.div>
                  </div>
                </div>
                <Link to={`/student/courses/${course.id}`} className="mt-auto text-indigo-400 text-[11px] font-black uppercase tracking-[0.3em] hover:translate-x-3 transition-all inline-flex items-center gap-3 italic">
                  INITIALIZE TRANSMISSION <ChevronRightIcon className="w-5 h-5" />
                </Link>
              </motion.div>
            )) : (
              <div className="col-span-full py-32 text-center">
                <div className="text-6xl mb-8 opacity-20 grayscale">📡</div>
                <p className="text-lg font-black text-slate-500 uppercase tracking-[0.4em] italic">NO ACTIVE COURSES DETECTED IN YOUR SECTOR.</p>
              </div>
            )}
          </div>
          <div className="mt-20 text-center">
            <Link to="/student/courses" className="inline-block px-16 py-8 bg-indigo-600 text-white rounded-[2rem] font-black uppercase text-xs tracking-[0.4em] shadow-3xl hover:bg-indigo-700 hover:scale-105 transition-all italic">
              VIEW ENTIRE MATRIX
            </Link>
          </div>
        </motion.div>
      </div>

      {/* AI Lab Launchpad */}
      <div className="mt-24">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-16 gap-8">
          <h2 className="text-5xl font-black text-white uppercase tracking-tighter italic leading-none">
            AI LAB <span className="text-indigo-500">LAUNCHPAD</span>
          </h2>
          <div className="px-8 py-4 bg-indigo-500/10 rounded-full border border-indigo-500/20 flex items-center gap-4">
            <div className="w-3 h-3 bg-indigo-500 rounded-full animate-ping"></div>
            <span className="text-[11px] font-black uppercase text-indigo-400 tracking-[0.3em] italic">LIVE RECOMMENDATION ENGINE</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="lg:col-span-1 bg-slate-950/60 backdrop-blur-2xl rounded-[4rem] p-12 text-white shadow-3xl border border-white/10 relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-transparent"></div>
            <RocketLaunchIcon className="w-24 h-24 text-white/5 absolute -right-8 -bottom-8 rotate-12" />
            <h3 className="text-3xl font-black uppercase tracking-tighter mb-8 italic relative z-10 leading-none">NEURAL<br />SYNTHESIZER</h3>
            <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-12 leading-relaxed italic relative z-10">
              FORGE A CUSTOM LAB ENVIRONMENT TAILORED TO YOUR CURRENT COGNITIVE VECTOR AND COURSE LOAD.
            </p>
            <button
              onClick={() => window.location.href = '/student/labs?generate=true'}
              className="w-full bg-white text-black py-6 rounded-[1.5rem] font-black uppercase text-[10px] tracking-[0.4em] shadow-2xl hover:bg-indigo-500 hover:text-white transition-all flex items-center justify-center gap-4 italic relative z-10"
            >
              <BoltIcon className="w-5 h-5" /> GENERATE LAB
            </button>
          </motion.div>

          <motion.div 
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="lg:col-span-3 bg-slate-950/40 backdrop-blur-2xl rounded-[4rem] p-12 shadow-3xl border border-white/10 flex flex-col"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 flex-1">
              {suggestedLabs.length > 0 ? suggestedLabs.slice(0, 3).map((lab, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ y: -10 }}
                  className="bg-white/5 p-8 rounded-[2.5rem] border border-white/5 group hover:border-indigo-400/50 transition-all flex flex-col"
                >
                  <div className="flex justify-between items-start mb-6">
                    <span className={`text-[9px] font-black uppercase px-3 py-1.5 rounded-lg border 
                        ${lab.difficulty === 'Easy' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                        lab.difficulty === 'Medium' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                          'bg-rose-500/10 text-rose-400 border-rose-500/20'}`}>
                      {lab.difficulty}
                    </span>
                    <BeakerIcon className="w-6 h-6 text-indigo-400 group-hover:scale-125 transition-transform" />
                  </div>
                  <h4 className="text-sm font-black text-white uppercase tracking-tighter italic mb-3 line-clamp-1">{lab.title}</h4>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed mb-8 line-clamp-2 italic">
                    {lab.description || 'PRACTICE CORE CONCEPTS IN THIS AI-DRIVEN LABORATORY.'}
                  </p>
                  <div className="mt-auto flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] italic">{lab.topics?.[0] || 'LOGIC'}</span>
                    <Link to={`/student/labs/${lab.id || lab._id}`} className="w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center group-hover:translate-x-2 transition-all shadow-lg">
                      <ChevronRightIcon className="w-5 h-5" />
                    </Link>
                  </div>
                </motion.div>
              )) : (
                <div className="col-span-full flex flex-col items-center justify-center py-20 opacity-30 italic font-black uppercase tracking-[0.5em] text-sm text-white">
                  RECALIBRATING RECOMMENDATIONS...
                </div>
              )}
            </div>
            <Link to="/student/labs" className="mt-12 text-center text-[11px] font-black text-indigo-400 uppercase tracking-[0.5em] hover:translate-x-3 transition-all italic underline decoration-2 underline-offset-8 decoration-indigo-500/50">
              EXPLORE FULL LAB MATRIX —→
            </Link>
          </motion.div>
        </div>
      </div>

      {/* Progress Matrix */}
      <div className="mt-24 mb-24">
        <h2 className="text-5xl font-black text-white mb-16 uppercase tracking-tighter italic leading-none">
          PROGRESS <span className="text-indigo-500">TRACKING</span>
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <motion.div 
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="bg-slate-950/40 backdrop-blur-2xl rounded-[4.5rem] p-16 shadow-3xl border border-white/10 relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-transparent"></div>
            <h3 className="text-2xl font-black mb-16 text-white uppercase tracking-tighter italic leading-none">WEEKLY OPTIMIZATION</h3>
            <div className="space-y-12">
              {overallProgress.length > 0 ? overallProgress.slice(0, 4).map((item, index) => (
                <div key={index}>
                  <div className="flex justify-between text-[11px] font-black uppercase tracking-[0.3em] mb-4">
                    <span className="text-slate-500 truncate max-w-[250px]">{item.courseId?.name || 'ACADEMIC COURSE'}</span>
                    <span className="text-indigo-400 italic">{item.completionPercentage || 0}%</span>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-4 p-1 border border-white/5">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${item.completionPercentage || 0}%` }}
                      className="bg-indigo-600 h-full rounded-full shadow-[0_0_15px_rgba(99,102,241,0.3)] transition-all duration-1000"
                    ></motion.div>
                  </div>
                </div>
              )) : (
                <div className="py-20 text-center text-slate-500 font-bold uppercase text-[11px] tracking-[0.5em] italic opacity-50">
                  NO PROGRESS METRICS CURRENTLY CACHED.
                </div>
              )}
            </div>
          </motion.div>

          <motion.div 
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="bg-slate-950/40 backdrop-blur-2xl rounded-[4.5rem] p-16 shadow-3xl border border-white/10"
          >
            <h3 className="text-2xl font-black mb-16 text-white uppercase tracking-tighter italic leading-none flex items-center justify-between">
              MILESTONES <span className="bg-indigo-500/10 text-indigo-400 px-6 py-2 rounded-full text-[10px] tracking-widest border border-indigo-500/20">ACTIVE CYCLE</span>
            </h3>
            <div className="space-y-8">
              {(achievements.length > 0 ? achievements : ACHIEVEMENTS_FALLBACK).slice(0, 3).map((achievement, idx) => (
                <motion.div 
                  key={idx} 
                  whileHover={{ scale: 1.05, x: 10 }}
                  className="flex items-center p-8 bg-white/5 rounded-[3rem] border border-white/5 group hover:border-indigo-500/50 transition-all"
                >
                  <div className="w-20 h-20 flex items-center justify-center text-4xl bg-slate-900 rounded-[1.5rem] shadow-2xl border border-white/10 group-hover:rotate-12 transition-transform mr-8 flex-shrink-0">
                    {achievement.icon || (achievement.badgeId?.icon) || '🎖️'}
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-white uppercase tracking-tighter italic leading-tight mb-2">{achievement.title || achievement.badgeId?.name || 'MILESTONE'}</h4>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] leading-none italic">{achievement.desc || achievement.badgeId?.description || 'OPERATIONAL MILESTONE ACHIEVED.'}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}

// Icon Fallback
function BeakerIcon() { return <AcademicCapIcon className="w-6 h-6" />; }
