import React from 'react';
import { motion } from 'framer-motion';
import { LightBulbIcon } from '@heroicons/react/24/outline';

export default function SentimentAnalyzer() {
    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="px-4 py-8 md:p-8 lg:p-12 max-w-[1700px] mx-auto min-h-screen pt-20 md:pt-24 font-sans"
        >
            <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-12 lg:mb-20 gap-8">
                <div>
                    <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-slate-900 dark:text-white tracking-tighter uppercase leading-none italic">
                        Sentiment <span className="text-pink-500">Analyzer</span>
                    </h1>
                    <p className="mt-4 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest text-[10px] md:text-xs">
                        Natural Language Processing for Campus Morale
                    </p>
                </div>
            </div>

            <div className="bg-white dark:bg-dark-900 rounded-[3rem] md:rounded-[4rem] p-8 md:p-12 shadow-3xl border border-slate-50 dark:border-dark-800 text-center relative overflow-hidden">
                <div className="absolute inset-0 bg-pink-500/5 opacity-50 pulse-bg animate-pulse"></div>
                <LightBulbIcon className="w-20 h-20 text-pink-500 mx-auto mb-6 opacity-30 animate-pulse" />
                <h2 className="text-2xl font-black uppercase tracking-tighter italic text-slate-900 dark:text-white relative z-10">Ingesting Discourse...</h2>
                <p className="text-slate-500 mt-4 max-w-lg mx-auto text-sm font-medium relative z-10">
                    Neural networks are actively scanning forum queries, feedback pipelines, and lab frustration indices to project the department's cumulative mental health threshold.
                </p>
            </div>
        </motion.div>
    );
}
