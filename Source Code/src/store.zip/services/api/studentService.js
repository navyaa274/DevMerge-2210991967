import apiClient from './apiClient';

/**
 * Student Service for profile and dashboard overview
 */
const studentService = {
    getProfileOverview: async () => {
        try {
            const response = await apiClient.get('/student/profile-overview');
            return response.data;
        } catch (error) {
            throw error.response?.data || error;
        }
    },

    getSubmissions: async () => {
        try {
            const response = await apiClient.get('/submissions/problem/all/my');
            return response.data;
        } catch (error) {
            throw error.response?.data || error;
        }
    },

    getEnrolledCourses: async () => {
        try {
            const response = await apiClient.get('/student/courses?enrolled=true');
            return response.data;
        } catch (error) {
            throw error.response?.data || error;
        }
    },

    getOverallProgress: async (userId) => {
        try {
            const response = await apiClient.get(`/progress/user/${userId}`);
            return response.data;
        } catch (error) {
            throw error.response?.data || error;
        }
    },

    getAchievements: async (userId) => {
        try {
            const response = await apiClient.get(`/badges/user/${userId}`);
            return response.data;
        } catch (error) {
            throw error.response?.data || error;
        }
    },

    getLeaderboard: async (type = 'global', limit = 10) => {
        try {
            const response = await apiClient.get(`/leaderboards/${type}?limit=${limit}`);
            return response.data;
        } catch (error) {
            throw error.response?.data || error;
        }
    },

    getUserPoints: async (userId) => {
        try {
            const response = await apiClient.get(`/points/user/${userId}`);
            return response.data;
        } catch (error) {
            throw error.response?.data || error;
        }
    },

    getActiveQuests: async () => {
        const endpoints = ['/quests', '/general/quests'];

        for (const endpoint of endpoints) {
            try {
                const response = await apiClient.get(endpoint);
                if (response.status >= 200 && response.status < 300) {
                    return response.data;
                }
            } catch (error) {
                if (error?.response?.status !== 404) {
                    throw error.response?.data || error;
                }
            }
        }

        throw new Error('Quest endpoints are unavailable');
    },

    acceptQuest: async (questId) => {
        const endpoints = [`/quests/${questId}/accept`, `/general/quests/${questId}/accept`];

        for (const endpoint of endpoints) {
            try {
                const response = await apiClient.post(endpoint);
                if (response.status >= 200 && response.status < 300) {
                    return response.data;
                }
            } catch (error) {
                if (error?.response?.status !== 404) {
                    throw error.response?.data || error;
                }
            }
        }

        throw new Error('Accept quest endpoint is unavailable');
    }
};

// Portfolio APIs
studentService.getPortfolio = async () => {
    try {
        const response = await apiClient.get('/student/portfolio');
        return response.data;
    } catch (error) {
        throw error.response?.data || error;
    }
};

studentService.updatePortfolio = async (payload) => {
    try {
        const response = await apiClient.put('/student/portfolio', payload);
        return response.data;
    } catch (error) {
        throw error.response?.data || error;
    }
};

export default studentService;
