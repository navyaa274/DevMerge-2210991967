import apiClient from './apiClient';
import { ENDPOINTS } from '../../config/urls';

/**
 * HOD (Head of Department) Management Service
 */
const normalizeDepartmentId = (deptRef) => {
    if (!deptRef) return '';
    if (typeof deptRef === 'string') return deptRef;
    return deptRef._id || deptRef.id || '';
};

const toError = (error, fallbackMessage) => {
    const message = error?.formattedMessage || error?.response?.data?.message || error?.message || fallbackMessage;
    return new Error(message);
};

const hodService = {
    // Get department overview including critical rates and totals
    getDepartmentOverview: async (deptRef) => {
        try {
            const deptId = normalizeDepartmentId(deptRef);
            if (!deptId) return { success: true, data: {} };
            const response = await apiClient.get(ENDPOINTS.INSTITUTIONAL.DEPARTMENT_OVERVIEW(deptId));
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to load department overview');
        }
    },

    // Get cognitive load indicators for department students
    getCognitiveLoadData: async (deptRef) => {
        try {
            const deptId = normalizeDepartmentId(deptRef);
            if (!deptId) return { success: true, data: [] };
            const response = await apiClient.get(ENDPOINTS.INSTITUTIONAL.COG_LOAD(deptId));
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to load cognitive load data');
        }
    },

    // Get operational efficiency metrics for the department
    getEfficiencyMetrics: async (deptRef) => {
        try {
            const deptId = normalizeDepartmentId(deptRef);
            if (!deptId) return { success: true, data: {} };
            const response = await apiClient.get(ENDPOINTS.INSTITUTIONAL.EFFICIENCY(deptId));
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to load efficiency metrics');
        }
    },

    // Get accreditation and attainment report for the department
    getAccreditationData: async (deptRef) => {
        try {
            const deptId = normalizeDepartmentId(deptRef);
            if (!deptId) return { success: true, data: {} };
            const response = await apiClient.get(ENDPOINTS.INSTITUTIONAL.ACCREDITATION(deptId));
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to load accreditation data');
        }
    },

    // Get faculty performance rankings for the department
    getFacultyPerformance: async (deptRef) => {
        try {
            const deptId = normalizeDepartmentId(deptRef);
            if (!deptId) return { success: true, data: [] };
            const response = await apiClient.get(ENDPOINTS.INSTITUTIONAL.FACULTY_PERFORMANCE(deptId));
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to load faculty performance');
        }
    },

    // Get departmental courses with faculty mappings
    getDepartmentCourses: async (deptRef) => {
        try {
            const deptId = normalizeDepartmentId(deptRef);
            if (!deptId) return { success: true, data: [] };
            const response = await apiClient.get(ENDPOINTS.INSTITUTIONAL.DEPARTMENT_COURSES(deptId));
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to load department courses');
        }
    },

    // Get workload comparison across all faculty in a department
    getWorkloadDistribution: async (deptRef) => {
        try {
            const deptId = normalizeDepartmentId(deptRef);
            if (!deptId) return { success: true, data: { workloadDistribution: [] } };
            const response = await apiClient.get(ENDPOINTS.INSTITUTIONAL.WORKLOAD_DISTRIBUTION(deptId));
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to load workload distribution');
        }
    },

    // Auto-assign students to sections
    autoAssignStudents: async (semesterId, config = {}) => {
        try {
            const response = await apiClient.post(ENDPOINTS.SECTIONS.AUTO_ASSIGN(semesterId), config);
            return response.data;
        } catch (error) {
            throw toError(error, 'Failed to auto-assign students');
        }
    }
};

export default hodService;
