import apiClient from "./apiClient";

/**
 * Faculty Management Service
 */
const facultyService = {
  // Track if quest history endpoint exists
  questHistoryAvailable: false,

  // Get faculty statistics (courses, students, credits)
  getDashboardStats: async (facultyId) => {
    try {
      const response = await apiClient.get(`/analytics/faculty/${facultyId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Get active academic year
  getActiveYear: async () => {
    try {
      const response = await apiClient.get("/academic-years/active");
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Get courses assigned to faculty
  getAssignedCourses: async (facultyId) => {
    try {
      const response = await apiClient.get("/courses", {
        params: { faculty: facultyId },
      });
      return response.data;
    } catch (error) {
      throw error.formattedMessage;
    }
  },

  // Get recent submissions for faculty courses
  getRecentSubmissions: async (params) => {
    try {
      const response = await apiClient.get("/submissions/faculty", { params });
      return response.data;
    } catch (error) {
      throw error.formattedMessage;
    }
  },

  // Fetch live cognitive telemetry
  getCognitiveTelemetry: async () => {
    try {
      const response = await apiClient.get("/analytics/telemetry/cognitive");
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Get flagged/auto-graded submissions for Override Panel
  getFlaggedSubmissions: async () => {
    try {
      const response = await apiClient.get("/faculty/submissions/flagged");
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Execute Auto-Grader Override
  overrideSubmission: async (submissionId, score, statusOverride = null) => {
    try {
      const response = await apiClient.put(
        `/faculty/submissions/${submissionId}/override`,
        { score, statusOverride },
      );
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // AI-Driven Cohort Generation
  generateSmartCohort: async (heuristic, groupSize, courseId) => {
    try {
      const response = await apiClient.post("/faculty/cohort/generate", {
        heuristic,
        groupSize,
        courseId
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Deploy System-Wide Global Broadcast (HOD function bound to this service file for simplicity)
  deployGlobalBroadcast: async (payload) => {
    try {
      const response = await apiClient.post("/hod/broadcast", payload);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Get live broadcast stats for telemetry panel
  getBroadcastStats: async () => {
    try {
      const response = await apiClient.get("/hod/broadcast-stats");
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Get transmission history
  getBroadcastHistory: async () => {
    try {
      const response = await apiClient.get("/hod/broadcast-history");
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Gamification Overrides
  getGamificationConfig: async () => {
    try {
      const response = await apiClient.get("/hod/gamification-config");
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  updateGamificationMultiplier: async (payload) => {
    try {
      const response = await apiClient.post(
        "/hod/gamification-multiplier",
        payload,
      );
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Zero-Day Quest Management
  deployZeroDayQuest: async (payload) => {
    try {
      const response = await apiClient.post(
        "/learning/faculty/quests",
        payload,
      );
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getQuestHistory: async () => {
    // Return empty array if endpoint has been confirmed to be unavailable
    if (!facultyService.questHistoryAvailable) {
      return [];
    }

    try {
      const response = await apiClient.get("/learning/faculty/quests/history");
      return response.data;
    } catch (error) {
      // Mark endpoint as unavailable to prevent further API calls
      facultyService.questHistoryAvailable = false;
      return [];
    }
  },

  getActiveQuests: async () => {
    try {
      const response = await apiClient.get("/learning/quests");
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  // Force check if quest history endpoint exists
  checkQuestHistoryAvailability: async () => {
    try {
      await apiClient.get("/learning/faculty/quests/history");
      facultyService.questHistoryAvailable = true;
      return true;
    } catch (error) {
      facultyService.questHistoryAvailable = false;
      return false;
    }
  },
};

export default facultyService;
