import React from "react";
import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import {
    HomeIcon,
    BookOpenIcon,
    CalendarIcon,
    AcademicCapIcon,
    BeakerIcon,
    CommandLineIcon,
    ChatBubbleBottomCenterTextIcon,
    UserGroupIcon,
    ChartBarIcon,
    BriefcaseIcon,
    UserCircleIcon,
    SparklesIcon,
    ShieldCheckIcon,
    Cog6ToothIcon,
} from "@heroicons/react/24/outline";
import { useAuthStore } from "../../store/authStore";
import HamburgerMenu from "./HamburgerMenu";

const SidebarItem = ({ item, isCompact, isActive }) => {
    return (
        <Link
            to={item.path}
            className={`lms-sidebar-item ${isActive ? "lms-sidebar-item-active" : "lms-sidebar-item-inactive"} transition-all duration-300`}
        >
            <div className={`flex items-center justify-center shrink-0 transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`}>
                <item.icon
                    className={`w-6 h-6 ${isActive ? "text-white" : "text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-white"}`}
                />
            </div>
            {!isCompact && (
                <motion.span
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`text-[11px] font-black uppercase tracking-[0.2em] whitespace-nowrap ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-white'}`}
                >
                    {item.name}
                </motion.span>
            )}
            {isActive && (
                <motion.div
                    layoutId="active-indicator"
                    className="absolute left-0 w-1 h-8 bg-white rounded-r-full shadow-[0_0_10px_rgba(255,255,255,0.8)]"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                />
            )}
            {isCompact && <div className="lms-sidebar-tooltip">{item.name}</div>}
        </Link>
    );
};

export default function Sidebar({ isCompact, setIsCompact, onMenuToggle }) {
    const { user } = useAuthStore();
    const location = useLocation();
    
    // Show hamburger menu only for faculty and student roles
    const shouldShowHamburger = user?.role === 'faculty' || user?.role === 'student';

    const getNavigation = () => {
        const base = [
            { name: "Dashboard", path: `/${user?.role}/dashboard`, icon: HomeIcon },
        ];

        if (user?.role === "student") {
            return [
                ...base,
                { name: "My Courses", path: "/student/courses", icon: BookOpenIcon },
                { name: "AI Tutor", path: "/student/ai-tutor", icon: SparklesIcon },
                { name: "Calendar", path: "/student/calendar", icon: CalendarIcon },
                { name: "Code Lab", path: "/student/labs", icon: CommandLineIcon },
                { name: "Problems", path: "/problems", icon: BeakerIcon },
                {
                    name: "Mock Interview",
                    path: "/student/mock-interview",
                    icon: ChatBubbleBottomCenterTextIcon,
                },
                { name: "Portfolio", path: "/student/portfolio", icon: BriefcaseIcon },
            ];
        }

        if (user?.role === "faculty") {
            return [
                ...base,
                {
                    name: "Course Management",
                    path: "/faculty/courses",
                    icon: BookOpenIcon,
                },
                { name: "Students", path: "/faculty/students", icon: UserGroupIcon },
                {
                    name: "Assessments",
                    path: "/faculty/assessments",
                    icon: AcademicCapIcon,
                },
                { name: "Analytics", path: "/faculty/analytics", icon: ChartBarIcon },
                { name: "Global Broadcast", path: "/hod/global-broadcast", icon: SparklesIcon }, // Linked for visibility
            ];
        }

        if (user?.role === "hod") {
            return [
                ...base,
                { name: "Broadcast Hub", path: "/hod/global-broadcast", icon: SparklesIcon },
                { name: "Department Info", path: "/hod/department", icon: AcademicCapIcon },
                { name: "Faculty Load", path: "/hod/faculty", icon: UserGroupIcon },
                { name: "Academic Programs", path: "/hod/programs", icon: BookOpenIcon },
                { name: "Node Analytics", path: "/hod/analytics", icon: ChartBarIcon },
                { name: "Audit Logs", path: "/hod/audit-logs", icon: ShieldCheckIcon },
                { name: "Policy Engine", path: "/hod/policy-engine", icon: Cog6ToothIcon },
            ];
        }

        if (user?.role === "admin" || user?.role === "super_admin") {
            return [
                ...base,
                {
                    name: "Departments",
                    path: "/admin/departments",
                    icon: AcademicCapIcon,
                },
                { name: "User Management", path: "/admin/users", icon: UserGroupIcon },
                { name: "Calendar", path: "/admin/calendar", icon: CalendarIcon },
                {
                    name: "Announcements",
                    path: "/admin/announcements",
                    icon: SparklesIcon,
                },
                { name: "Reports", path: "/admin/reports", icon: ChartBarIcon },
                {
                    name: "API Management",
                    path: "/admin/api-keys",
                    icon: CommandLineIcon,
                },
                {
                    name: "Moderation",
                    path: "/admin/moderation",
                    icon: ShieldCheckIcon,
                },
                { name: "Settings", path: "/admin/settings", icon: Cog6ToothIcon },
            ];
        }

        return base;
    };

    const navItems = getNavigation();

    return (
        <aside className="flex flex-col h-full relative z-10 overflow-hidden">
            <div
                className={`h-20 flex items-center justify-between px-6 shrink-0 ${isCompact ? "justify-center" : ""}`}
            >
                <Link to="/" className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-black italic shadow-lg shadow-indigo-500/20 shrink-0">
                        DM
                    </div>
                    {!isCompact && (
                        <motion.span
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="text-xl font-black text-slate-900 dark:text-white tracking-tighter uppercase italic truncate"
                        >
                            DevMerge
                        </motion.span>
                    )}
                </Link>
                {shouldShowHamburger && (
                    <HamburgerMenu
                        isOpen={!isCompact}
                        onToggle={onMenuToggle}
                        className="lg:hidden"
                    />
                )}
            </div>

            <nav className="flex-1 px-4 py-8 space-y-2 overflow-y-auto custom-scrollbar overflow-x-hidden">
                {navItems.map((item) => (
                    <SidebarItem
                        key={item.name}
                        item={item}
                        isCompact={isCompact}
                        isActive={location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path))}
                    />
                ))}
            </nav>

            <div className="p-4 border-t border-slate-50 dark:border-dark-800">
                <button
                    onClick={() => setIsCompact(!isCompact)}
                    className="w-full h-14 flex items-center justify-center bg-slate-50 dark:bg-dark-900 rounded-2xl text-slate-400 hover:text-indigo-600 transition-all text-[10px] font-black uppercase tracking-widest gap-2"
                >
                    {isCompact ? "→" : "← Collapse"}
                </button>
            </div>
        </aside>
    );
}
