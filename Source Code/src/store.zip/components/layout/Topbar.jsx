import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MagnifyingGlassIcon, BellIcon, UserIcon, Cog6ToothIcon, ArrowRightOnRectangleIcon } from '@heroicons/react/24/outline';
import { useAuthStore } from '../../store/authStore';
import DarkModeToggle from '../DarkModeToggle';
import NotificationCenter from '../NotificationCenter';
import SearchModal from '../SearchModal';
import HamburgerMenu from './HamburgerMenu';

export default function Topbar({ onMenuButtonClick, isSidebarOpen, isLargeScreen, isCompact }) {
    const { user, logout } = useAuthStore();
    const [isSearchOpen, setIsSearchOpen] = useState(false);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                setIsSearchOpen(true);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    // Sidebar state for icon animation
    const isSidebarActive = isLargeScreen ? !isCompact : isSidebarOpen;
    
    // Show hamburger menu only for faculty and student roles on all screen sizes
    const shouldShowHamburger = user?.role === 'faculty' || user?.role === 'student';

    return (
        <header className="h-20 flex items-center justify-between px-6 md:px-10 bg-white/80 dark:bg-dark-950/80 backdrop-blur-md border-b border-slate-100 dark:border-dark-800 sticky top-0 z-[90]">
            <div className="flex items-center gap-4">
                {shouldShowHamburger && (
                    <HamburgerMenu
                        isOpen={isSidebarActive}
                        onToggle={onMenuButtonClick}
                    />
                )}

                {/* Show logo on mobile OR on desktop if sidebar is compact */}
                <Link to="/" className={`flex items-center gap-2 transition-all duration-300 ${isCompact || !isLargeScreen ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4 pointer-events-none absolute'}`}>
                    <div className="w-8 h-8 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black italic shadow-lg shadow-indigo-500/20">
                        DM
                    </div>
                    <span className="text-lg font-black text-slate-900 dark:text-white tracking-tighter uppercase italic">DevMerge</span>
                </Link>

                <div className="hidden sm:flex items-center bg-slate-50 dark:bg-dark-900 border border-slate-100 dark:border-dark-800 rounded-2xl px-4 py-2.5 w-64 lg:w-96 transition-all focus-within:ring-4 focus-within:ring-indigo-500/10 group">
                    <MagnifyingGlassIcon className="w-5 h-5 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
                    <input
                        type="text"
                        placeholder="Search matrix..."
                        className="bg-transparent border-none focus:ring-0 text-sm ml-2 w-full text-slate-600 dark:text-slate-300 placeholder:text-slate-400 font-medium"
                        onClick={() => setIsSearchOpen(true)}
                        readOnly
                    />
                    <kbd className="hidden md:inline-flex items-center gap-1 px-2 py-1 rounded-lg border border-slate-200 dark:border-dark-700 bg-white dark:bg-dark-950 text-[10px] font-black text-slate-400 shadow-sm">
                        ⌘K
                    </kbd>
                </div>
            </div>

            <div className="flex items-center gap-3 md:gap-6">
                <div className="flex items-center gap-2">
                    <DarkModeToggle />
                    <NotificationCenter />
                </div>

                <div className="h-8 w-px bg-slate-100 dark:bg-dark-800 hidden sm:block"></div>

                <div className="flex items-center gap-3">
                    <Link to="/profile" className="flex items-center gap-3 p-1 rounded-2xl bg-white dark:bg-dark-900 border border-slate-100 dark:border-dark-800 hover:border-indigo-500/30 transition-all group lg:pr-4">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-black text-sm shadow-lg group-hover:scale-105 transition-transform overflow-hidden">
                            {user?.profilePicture ? (
                                <img src={user.profilePicture} alt="User" className="w-full h-full object-cover" />
                            ) : (
                                (user?.name || user?.email || 'U').charAt(0).toUpperCase()
                            )}
                        </div>
                        <div className="hidden lg:block text-left">
                            <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.1em] leading-none mb-1">
                                {user?.role?.replace('_', ' ')}
                            </p>
                            <p className="text-xs font-bold text-slate-900 dark:text-white leading-none truncate max-w-[120px]">
                                {user?.name || 'User'}
                            </p>
                        </div>
                    </Link>

                    <button
                        onClick={logout}
                        className="p-2.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-all"
                        title="Logout"
                    >
                        <ArrowRightOnRectangleIcon className="w-6 h-6" />
                    </button>
                </div>
            </div>

            <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
        </header>
    );
}
