import React, { useState, useEffect } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Sample data for charts
const userActivityData = [
  { month: 'Jan', activeUsers: 1200, newUsers: 300, sessions: 4500 },
  { month: 'Feb', activeUsers: 1350, newUsers: 280, sessions: 4800 },
  { month: 'Mar', activeUsers: 1500, newUsers: 350, sessions: 5200 },
  { month: 'Apr', activeUsers: 1650, newUsers: 320, sessions: 5500 },
  { month: 'May', activeUsers: 1800, newUsers: 400, sessions: 5800 },
  { month: 'Jun', activeUsers: 1950, newUsers: 380, sessions: 6100 }
];

const coursePerformanceData = [
  { course: 'Data Structures', completion: 85, enrollment: 120, avgScore: 78 },
  { course: 'Algorithms', completion: 78, enrollment: 95, avgScore: 82 },
  { course: 'Web Development', completion: 92, enrollment: 150, avgScore: 88 },
  { course: 'Machine Learning', completion: 70, enrollment: 80, avgScore: 75 },
  { course: 'Database Systems', completion: 88, enrollment: 110, avgScore: 85 }
];

const deviceUsageData = [
  { name: 'Desktop', value: 45, color: '#8884d8' },
  { name: 'Mobile', value: 35, color: '#82ca9d' },
  { name: 'Tablet', value: 20, color: '#ffc658' }
];

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#00ff00'];

const AdvancedAnalyticsDashboard = () => {
  const [timeRange, setTimeRange] = useState('6months');
  const [selectedMetric, setSelectedMetric] = useState('users');

  useEffect(() => {
    // Fetch real data from API
    // const fetchData = async () => {
    //   const response = await api.get('/analytics/dashboard');
    //   setData(response.data);
    // };
    // fetchData();
  }, [timeRange, selectedMetric]);

  return (
    <div className="advanced-analytics-dashboard p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Advanced Analytics Dashboard</h1>

        {/* Controls */}
        <div className="mb-8 flex flex-wrap gap-4">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
          >
            <option value="7days">Last 7 Days</option>
            <option value="30days">Last 30 Days</option>
            <option value="3months">Last 3 Months</option>
            <option value="6months">Last 6 Months</option>
            <option value="1year">Last Year</option>
          </select>

          <select
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
          >
            <option value="users">User Analytics</option>
            <option value="courses">Course Performance</option>
            <option value="engagement">Engagement Metrics</option>
            <option value="system">System Health</option>
          </select>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-700">Total Users</h3>
            <p className="text-3xl font-bold text-blue-600">12,456</p>
            <p className="text-sm text-green-600">+12% from last month</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-700">Active Courses</h3>
            <p className="text-3xl font-bold text-green-600">247</p>
            <p className="text-sm text-blue-600">+8% from last month</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-700">Completion Rate</h3>
            <p className="text-3xl font-bold text-purple-600">78%</p>
            <p className="text-sm text-orange-600">+3% from last month</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-700">Avg Session Time</h3>
            <p className="text-3xl font-bold text-red-600">24m</p>
            <p className="text-sm text-green-600">+5% from last month</p>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* User Activity Trend */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">User Activity Trend</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={userActivityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="activeUsers" stroke="#8884d8" strokeWidth={2} />
                <Line type="monotone" dataKey="newUsers" stroke="#82ca9d" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Course Performance */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Course Performance</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={coursePerformanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="course" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="completion" fill="#8884d8" />
                <Bar dataKey="avgScore" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Device Usage */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Device Usage</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={deviceUsageData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {deviceUsageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Engagement Metrics */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Engagement Metrics</h2>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={userActivityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="sessions" stackId="1" stroke="#8884d8" fill="#8884d8" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed Analytics Table */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Detailed Analytics</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full table-auto">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-2 text-left">Metric</th>
                  <th className="px-4 py-2 text-left">Current</th>
                  <th className="px-4 py-2 text-left">Previous</th>
                  <th className="px-4 py-2 text-left">Change</th>
                  <th className="px-4 py-2 text-left">Trend</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="px-4 py-2">Total Users</td>
                  <td className="px-4 py-2">12,456</td>
                  <td className="px-4 py-2">11,123</td>
                  <td className="px-4 py-2 text-green-600">+12%</td>
                  <td className="px-4 py-2">📈</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-4 py-2">Course Completions</td>
                  <td className="px-4 py-2">8,945</td>
                  <td className="px-4 py-2">8,234</td>
                  <td className="px-4 py-2 text-green-600">+9%</td>
                  <td className="px-4 py-2">📈</td>
                </tr>
                <tr>
                  <td className="px-4 py-2">Average Score</td>
                  <td className="px-4 py-2">82.5%</td>
                  <td className="px-4 py-2">81.2%</td>
                  <td className="px-4 py-2 text-green-600">+1.3%</td>
                  <td className="px-4 py-2">📈</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-4 py-2">Session Duration</td>
                  <td className="px-4 py-2">24m 32s</td>
                  <td className="px-4 py-2">23m 15s</td>
                  <td className="px-4 py-2 text-green-600">+5%</td>
                  <td className="px-4 py-2">📈</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedAnalyticsDashboard;
